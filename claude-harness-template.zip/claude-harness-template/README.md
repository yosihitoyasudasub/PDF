# claude-harness-template

Claude Code 用のスペック駆動開発ハーネス一式のテンプレートリポジトリ。REBIRTH（space-craft）プロジェクトで実運用・改善してきたスキル・エージェント・コマンド・設定を、新プロジェクトで流用するための出発点。

## 含まれるもの

```
CLAUDE.md              # プロジェクト指示の骨格（{プレースホルダ} を記入して使う）
docs/                  # 永続ドキュメント置き場（/setup-project で生成）
.claude/
├── settings.json      # 許可リスト（npm/TS デフォルト）+ Stop フック（tasklist 完遂の押し戻し + .gate-wait ゲート待ち例外）
├── agents/            # planner / evaluator / doc-reviewer
├── commands/          # /setup-project /add-feature /review-docs /evaluate-harness
├── skills/            # steering / proposal / work-queue + docs 生成8スキル + testing / add-feature / review-docs
└── workflows/         # batch-refactor.js（一括リファクタリング用）
```

## 新プロジェクトの始め方

1. このリポジトリを「Use this template」（または clone して .git を作り直し）で複製
2. `CLAUDE.md` の `{プレースホルダ}` を記入（技術スタック・検証コマンド・重点リソース）
3. `.claude/settings.json` の許可リストをスタックに合わせて調整（npm 以外なら Bash 系エントリと PostToolUse の tsc フックを差し替え）
4. Claude Code で `/setup-project` を実行 → PRD 承認後、`docs/` の永続ドキュメント8種が生成される
5. 以降は `/add-feature` → steering → `/work-queue` のループで開発

## 運用の要点

- **tasklist 完全完了の原則**: Stop フックが未完了タスク（`- [ ]`）残存時の停止を押し戻す。Evaluator ゲート待ちは `.steering/[task]/.gate-wait` マーカー（60分有効）で例外化される（steering スキル モード2 ステップ4 参照）
- **負債ゲート**: ファイル300行超・重複3例目・リソース解放漏れ・`as unknown` 新規追加は全スプリント共通の合格条件（重点リソースは CLAUDE.md で定義）
- **検証コマンドの単一情報源**: evaluator・workflows は CLAUDE.md の「ビルド・検証コマンド」節を参照する
- **ハーネスの改善**: 各タスクの振り返り「ハーネスへのフィードバック」と `/evaluate-harness` で継続改善し、汎用的な改善は本テンプレートに逆輸入する

## 前提スタック

スキルのコード例（testing パターン・development-guidelines）は React + TypeScript + Vitest を想定している。別スタックでは該当スキルの例を読み替えるか差し替える。

## 由来

- 元プロジェクト: https://github.com/yosihitoyasudasub/space-craft
- ハーネス全体の俯瞰: 元プロジェクトの `docs/ideas/ai-coding-overview.md` を参照
