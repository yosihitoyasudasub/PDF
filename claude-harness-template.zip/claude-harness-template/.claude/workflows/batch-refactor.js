export const meta = {
  name: 'batch-refactor',
  description: '同型の変換作業を対象リストに順次適用し、各件を検証、最後に全体検証する',
  whenToUse: 'リファクタリングや移行など「対象リストが明確で、各項目に同じ変換を繰り返す」作業。args: { instruction: 変換指示, targets: 対象の配列, parallel?: true(対象同士が触るファイルが重ならない場合のみ), finalCheck?: false で全体検証を省略 }',
  phases: [
    { title: 'Transform', detail: '各対象に変換を適用' },
    { title: 'Verify', detail: '各対象を個別検証' },
    { title: 'FinalCheck', detail: 'tsc / jest / lint の全体検証' },
  ],
}

const VERDICT = {
  type: 'object',
  properties: {
    ok: { type: 'boolean' },
    details: { type: 'string' },
  },
  required: ['ok', 'details'],
}

const cfg = args || {}
if (!cfg.instruction || !Array.isArray(cfg.targets) || cfg.targets.length === 0) {
  return { error: 'args に { instruction: string, targets: string[] } が必要です' }
}

const transformPrompt = (t) =>
  `あなたは本プロジェクトのリファクタリング担当（技術スタックは CLAUDE.md を参照）。\n` +
  `CLAUDE.md と docs/development-guidelines.md の規約に従うこと。挙動・セーブデータ互換・外部APIは変えない。\n\n` +
  `変換指示: ${cfg.instruction}\n今回の対象: ${t}\n\n` +
  `完了後、変更したファイルの一覧と変更要約を返す。`

const verifyPrompt = (t, summary) =>
  `直前の変換を検証せよ。対象: ${t}\n変換の要約: ${summary}\n\n` +
  `CLAUDE.md のビルド・検証コマンド（型チェックと、対象に関連する単体テスト）を実行し、\n` +
  `1) コンパイル・テストが通るか 2) 変換指示どおりか 3) 挙動を変える差分が紛れていないか を確認。\n` +
  `結果を ok / details で返す。`

const results = []

if (cfg.parallel === true) {
  // 対象同士が触るファイルが重ならない前提。重なる場合は直列（デフォルト）を使うこと。
  const out = await pipeline(
    cfg.targets,
    (t) => agent(transformPrompt(t), { label: `transform:${t}`, phase: 'Transform' }),
    (summary, t) =>
      agent(verifyPrompt(t, summary), { label: `verify:${t}`, phase: 'Verify', schema: VERDICT })
        .then((v) => ({ target: t, summary, verdict: v })),
  )
  results.push(...out.filter(Boolean))
} else {
  // デフォルトは直列: 共有ファイル（基底クラス・store 等）を触るリファクタで安全
  for (const t of cfg.targets) {
    const summary = await agent(transformPrompt(t), { label: `transform:${t}`, phase: 'Transform' })
    if (summary === null) { results.push({ target: t, verdict: { ok: false, details: 'transform agent が失敗' } }); continue }
    const verdict = await agent(verifyPrompt(t, summary), { label: `verify:${t}`, phase: 'Verify', schema: VERDICT })
    results.push({ target: t, summary, verdict })
    if (verdict && !verdict.ok) {
      log(`対象 ${t} の検証が不合格: ${verdict.details} — 後続を中断`)
      break
    }
  }
}

let finalCheck = null
if (cfg.finalCheck !== false) {
  finalCheck = await agent(
    'CLAUDE.md のビルド・検証コマンド（型チェック・テスト・リント）を順に実行し、全体が健全か確認。結果を ok / details で返す。',
    { label: 'final-check', phase: 'FinalCheck', schema: VERDICT },
  )
}

return {
  done: results.filter((r) => r.verdict && r.verdict.ok).map((r) => r.target),
  failed: results.filter((r) => !r.verdict || !r.verdict.ok),
  skipped: cfg.targets.slice(results.length),
  finalCheck,
}
