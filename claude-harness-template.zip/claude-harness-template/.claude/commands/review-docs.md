---
description: ドキュメントの詳細レビューをサブエージェントで実行
---

# ドキュメントレビュー

`Skill` ツールで `review-docs` スキルを起動し、引数（ドキュメントパス）をそのまま渡すこと。

ワークフローの定義は `.claude/skills/review-docs/SKILL.md` が唯一の情報源。このファイルには手順を記載しない。
