---
description: 新機能を3エージェント構成（Planner→Generator→Evaluator）で実装する
---

# 新機能の追加

`Skill` ツールで `add-feature` スキルを起動し、引数（機能名）をそのまま渡すこと。

ワークフローの定義は `.claude/skills/add-feature/SKILL.md` が唯一の情報源。このファイルには手順を記載しない。
