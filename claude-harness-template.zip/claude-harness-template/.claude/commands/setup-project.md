---
description: 初回セットアップ: 永続ドキュメントを作成し、開発環境を構築する
---

# 初回プロジェクトセットアップ

`Skill` ツールで `setup-project` スキルを起動すること。

ワークフローの定義は `.claude/skills/setup-project/SKILL.md` が唯一の情報源。このファイルには手順を記載しない。
