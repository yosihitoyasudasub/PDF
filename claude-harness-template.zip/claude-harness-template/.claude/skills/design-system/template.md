# デザインシステム (Design System)

## 概要

このドキュメントは、プロダクト全体で一貫したUIを実現するためのデザインシステムを定義します。

## デザイン原則

### 基本方針

| 原則 | 説明 |
|------|------|
| シンプルさ | [説明] |
| 一貫性 | [説明] |
| アクセシビリティ | [説明] |

## カラーパレット

### プライマリカラー

| 名前 | HEX | 用途 |
|------|-----|------|
| Primary | `#[HEX]` | メインアクション、ブランドカラー |
| Primary Light | `#[HEX]` | ホバー状態、背景 |
| Primary Dark | `#[HEX]` | アクティブ状態 |

### セカンダリカラー

| 名前 | HEX | 用途 |
|------|-----|------|
| Secondary | `#[HEX]` | 補助的なアクション |
| Secondary Light | `#[HEX]` | ホバー状態 |
| Secondary Dark | `#[HEX]` | アクティブ状態 |

### セマンティックカラー

| 名前 | HEX | 用途 |
|------|-----|------|
| Success | `#22C55E` | 成功、完了 |
| Warning | `#F59E0B` | 警告、注意 |
| Error | `#EF4444` | エラー、削除 |
| Info | `#3B82F6` | 情報、ヒント |

### ニュートラルカラー

| 名前 | HEX | 用途 |
|------|-----|------|
| Background | `#FFFFFF` | 背景 |
| Surface | `#F9FAFB` | カード、パネル |
| Border | `#E5E7EB` | 境界線 |
| Text Primary | `#111827` | 本文 |
| Text Secondary | `#6B7280` | 補助テキスト |
| Text Disabled | `#9CA3AF` | 無効状態 |

## タイポグラフィ

### フォントファミリー

| 用途 | フォント | フォールバック |
|------|---------|---------------|
| 見出し | [フォント名] | sans-serif |
| 本文 | [フォント名] | sans-serif |
| コード | [フォント名] | monospace |

### フォントサイズ

| 名前 | サイズ | 行高 | 用途 |
|------|--------|------|------|
| xs | 12px | 1.5 | キャプション、ラベル |
| sm | 14px | 1.5 | 補助テキスト |
| base | 16px | 1.5 | 本文 |
| lg | 18px | 1.5 | 強調テキスト |
| xl | 20px | 1.4 | 小見出し |
| 2xl | 24px | 1.3 | 見出し |
| 3xl | 30px | 1.2 | 大見出し |
| 4xl | 36px | 1.1 | ヒーローテキスト |

### フォントウェイト

| 名前 | 値 | 用途 |
|------|-----|------|
| Regular | 400 | 本文 |
| Medium | 500 | 強調 |
| Semibold | 600 | 見出し |
| Bold | 700 | 強い強調 |

## スペーシング

### 基本単位

基本単位: `4px`

| 名前 | 値 | 用途 |
|------|-----|------|
| 0 | 0px | なし |
| 1 | 4px | 最小間隔 |
| 2 | 8px | コンパクト |
| 3 | 12px | 小 |
| 4 | 16px | 標準 |
| 5 | 20px | 中 |
| 6 | 24px | 大 |
| 8 | 32px | セクション間 |
| 10 | 40px | 大セクション間 |
| 12 | 48px | ページセクション |

## 角丸 (Border Radius)

| 名前 | 値 | 用途 |
|------|-----|------|
| none | 0px | 角丸なし |
| sm | 4px | 小さいボタン、タグ |
| md | 8px | カード、入力フィールド |
| lg | 12px | モーダル、パネル |
| xl | 16px | 大きなカード |
| full | 9999px | 円形、ピル型 |

## シャドウ

| 名前 | 値 | 用途 |
|------|-----|------|
| sm | `0 1px 2px rgba(0,0,0,0.05)` | 微細な浮き |
| md | `0 4px 6px rgba(0,0,0,0.1)` | カード |
| lg | `0 10px 15px rgba(0,0,0,0.1)` | ドロップダウン |
| xl | `0 20px 25px rgba(0,0,0,0.15)` | モーダル |

## ブレークポイント

| 名前 | 値 | デバイス |
|------|-----|---------|
| sm | 640px | スマートフォン（横向き） |
| md | 768px | タブレット |
| lg | 1024px | ノートPC |
| xl | 1280px | デスクトップ |
| 2xl | 1536px | 大画面 |

## コンポーネント規約

### ボタン

#### バリエーション

| バリエーション | 用途 |
|--------------|------|
| Primary | メインアクション（1画面に1つ） |
| Secondary | 補助的なアクション |
| Outline | キャンセル、戻る |
| Ghost | テキストリンク風 |
| Destructive | 削除、危険な操作 |

#### サイズ

| サイズ | 高さ | パディング | フォントサイズ |
|--------|------|-----------|--------------|
| sm | 32px | 12px 16px | 14px |
| md | 40px | 16px 24px | 16px |
| lg | 48px | 20px 32px | 18px |

#### 状態

- **Default**: 通常状態
- **Hover**: マウスオーバー
- **Active**: クリック中
- **Disabled**: 無効状態
- **Loading**: 読み込み中

### 入力フィールド

#### サイズ

| サイズ | 高さ | パディング |
|--------|------|-----------|
| sm | 32px | 8px 12px |
| md | 40px | 12px 16px |
| lg | 48px | 16px 20px |

#### 状態

- **Default**: 通常状態
- **Focus**: フォーカス時（Primary色のボーダー）
- **Error**: エラー時（Error色のボーダー）
- **Disabled**: 無効状態

### カード

| プロパティ | 値 |
|-----------|-----|
| 背景色 | Surface |
| 角丸 | md (8px) |
| シャドウ | sm |
| パディング | 16px - 24px |

## アイコン

### サイズ

| 名前 | サイズ | 用途 |
|------|--------|------|
| xs | 12px | インライン |
| sm | 16px | ボタン内 |
| md | 20px | 標準 |
| lg | 24px | 強調 |
| xl | 32px | 見出し |

### 推奨ライブラリ

- [ライブラリ名]: [理由]

## アニメーション

### デュレーション

| 名前 | 値 | 用途 |
|------|-----|------|
| fast | 150ms | ホバー、トグル |
| normal | 300ms | 標準的なトランジション |
| slow | 500ms | 大きな変化、モーダル |

### イージング

| 名前 | 値 | 用途 |
|------|-----|------|
| ease-out | cubic-bezier(0, 0, 0.2, 1) | 要素の出現 |
| ease-in | cubic-bezier(0.4, 0, 1, 1) | 要素の退出 |
| ease-in-out | cubic-bezier(0.4, 0, 0.2, 1) | 状態変化 |

## アクセシビリティ

### カラーコントラスト

- **AA準拠**: 通常テキスト 4.5:1以上
- **AA準拠**: 大テキスト 3:1以上
- **AAA準拠**: 通常テキスト 7:1以上（推奨）

### フォーカス表示

- すべてのインタラクティブ要素に視認可能なフォーカスリングを表示
- キーボードナビゲーション対応

### ARIAラベル

- アイコンのみのボタンには`aria-label`を付与
- フォーム要素には適切なラベルを関連付け

## CSS変数定義

**重要**: 変数名は `screen-design.md` と統一すること。シンプルなプレフィックスを使用する。

```css
:root {
  /* Background Colors: --bg-[用途] */
  --bg-primary: #[HEX];       /* ページ背景 */
  --bg-surface: #[HEX];       /* カード背景 */
  --bg-muted: #[HEX];         /* 非アクティブ状態 */
  --bg-accent-light: #[HEX];  /* アクセント背景 */

  /* Text Colors: --text-[用途] */
  --text-primary: #[HEX];     /* 見出し、主要テキスト */
  --text-secondary: #[HEX];   /* 副次テキスト */
  --text-tertiary: #[HEX];    /* 補足テキスト */

  /* Accent Colors: --accent-[用途] */
  --accent-primary: #[HEX];   /* メインアクセント */
  --accent-primary-dark: #[HEX]; /* ホバー/アクティブ */
  --accent-warm: #[HEX];      /* 警告アクセント */

  /* Semantic Colors: --[用途] */
  --success: #22C55E;
  --warning: #F59E0B;
  --error: #EF4444;
  --info: #3B82F6;

  /* Border Colors: --border-[用途] */
  --border-subtle: #[HEX];
  --border-strong: #[HEX];

  /* Typography */
  --font-sans: [フォント名], sans-serif;
  --font-mono: [フォント名], monospace;

  /* Spacing */
  --space-1: 4px;
  --space-2: 8px;
  --space-3: 12px;
  --space-4: 16px;
  --space-6: 24px;
  --space-8: 32px;

  /* Border Radius */
  --radius-sm: 4px;
  --radius-md: 8px;
  --radius-lg: 12px;
  --radius-full: 9999px;

  /* Shadows */
  --shadow-sm: 0 1px 2px rgba(0,0,0,0.05);
  --shadow-md: 0 4px 6px rgba(0,0,0,0.1);
  --shadow-lg: 0 10px 15px rgba(0,0,0,0.1);

  /* Transitions */
  --duration-fast: 150ms;
  --duration-normal: 300ms;
  --duration-slow: 500ms;
}
```

### 命名規則

| カテゴリ | プレフィックス | 例 |
|---------|--------------|-----|
| 背景色 | `--bg-` | `--bg-primary`, `--bg-surface` |
| テキスト色 | `--text-` | `--text-primary`, `--text-secondary` |
| アクセント色 | `--accent-` | `--accent-primary`, `--accent-warm` |
| ボーダー色 | `--border-` | `--border-subtle`, `--border-strong` |

**避けるべき命名**: `--color-bg-primary`（冗長）、`--background-color`（長すぎる）
