# setup-project スキル

初回プロジェクトセットアップを行うスキル。このファイルがワークフローの唯一の定義（`.claude/commands/setup-project.md` は本スキルを起動するだけのラッパー）。

## 概要

プロジェクトの永続ドキュメント（`docs/`）を対話的に作成し、開発環境（Vite + React + TypeScript、`CLAUDE.md` §技術スタック参照）を検証する。

## 処理フロー

### フェーズ1: インプットの読み込み

1. `docs/ideas/` 内のマークダウンファイルを全て読む
2. ファイルが存在する場合はその内容を元にPRDを作成、存在しない場合は対話形式でPRDを作成する

### フェーズ2: 永続ドキュメントの作成

以下のドキュメントを順番に作成する。**PRD（1番目）はユーザーに確認を求め、承認されるまで待機する。以降のドキュメント（2〜8番目）はPRDの内容を元にするため、承認を待たず自動的に作成する**（`CLAUDE.md` ドキュメント作成ルールの例外として明記済み）。各ドキュメントは対応するスキルのテンプレートとガイドに従い、既存の作成済みドキュメントを読んでから作成する。

| 順 | ドキュメント | 使用スキル |
|---|---|---|
| 1 | `docs/product-requirements.md` | `prd-writing` |
| 2 | `docs/functional-design.md` | `functional-design` |
| 3 | `docs/design-system.md` | `design-system` |
| 4 | `docs/screen-design.md` | `screen-design` |
| 5 | `docs/architecture.md` | `architecture-design` |
| 6 | `docs/repository-structure.md` | `repository-structure` |
| 7 | `docs/development-guidelines.md` | `development-guidelines` |
| 8 | `docs/glossary.md` | `glossary-creation` |

PRDでは、アイデアを詳細なユーザーストーリー・受け入れ条件・非機能要件・成功指標に具体化する。

### フェーズ3: ディレクトリ構造の作成

リポジトリ構造定義書（`docs/repository-structure.md`）に従い、必要なディレクトリとファイルを作成する。

### フェーズ4: 動作確認

1. `npm install` を実行（未実行の場合）
2. `npx tsc --noEmit` でTypeScriptエラーがないことを確認
3. `npm run dev` で開発サーバーが正常に起動することを確認

環境検証で問題が見つかった場合、修正前にユーザーに確認する。

## 完了条件

- 8つの永続ドキュメントがすべて作成され、PRDがユーザーに承認されている
- ディレクトリ構造が作成されている
- `npx tsc --noEmit` がエラーなく完了し、開発サーバーの起動が確認できている

完了時に、作成したドキュメント一覧と今後の使い方（会話でのドキュメント編集、`/add-feature [機能名]`、`/review-docs [パス]`）をユーザーに案内する。

## CSS変数の命名規則

design-system.md と screen-design.md で使用するCSS変数名は統一すること:

```css
:root {
  /* 背景色: --bg-[用途] */
  --bg-primary: #F5F4F1;
  --bg-surface: #FFFFFF;
  --bg-muted: #EDECEA;

  /* テキスト色: --text-[用途] */
  --text-primary: #1A1918;
  --text-secondary: #6D6C6A;

  /* アクセント色: --accent-[用途] */
  --accent-primary: #3D8A5A;
  --accent-warm: #D89575;

  /* ボーダー: --border-[用途] */
  --border-subtle: #E5E4E1;
}
```

**原則**:
1. シンプルなプレフィックス: `--bg-`, `--text-`, `--accent-`, `--border-`
2. 用途を明示: `primary`, `secondary`, `muted`, `surface` 等
3. 冗長な階層を避ける: `--color-bg-primary` ではなく `--bg-primary`
4. design-system.md と screen-design.md で同じ名前を使用する
