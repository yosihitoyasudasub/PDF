# エンジン層テストパターン

エンジン層（`src/engine/`）のテスト作成ガイドです。

## 対象

- StateManager
- Evaluator
- EndingRouter
- GameController
- ScenarioRunner

## 特徴

- 純粋なTypeScript/JavaScript
- 外部依存なし（React不要）
- 高速に実行可能

## 基本パターン

### 状態管理のテスト（StateManager）

```typescript
import { describe, it, expect } from 'vitest';
import { StateManager, applyDelta } from '../StateManager';

describe('StateManager', () => {
  describe('applyDelta', () => {
    it('should apply positive delta correctly', () => {
      const state = { trustAI: 50, trustBoss: 50, risk: 30, turn: 1 };
      const delta = { trustAI: 10 };

      const newState = applyDelta(state, delta);

      expect(newState.trustAI).toBe(60);
      expect(newState.turn).toBe(2); // turn は自動インクリメント
    });

    it('should clamp values at 100', () => {
      const state = { trustAI: 95, trustBoss: 50, risk: 30, turn: 1 };
      const delta = { trustAI: 10 };

      const newState = applyDelta(state, delta);

      expect(newState.trustAI).toBe(100); // 105 ではなく 100
    });

    it('should clamp values at 0', () => {
      const state = { trustAI: 5, trustBoss: 50, risk: 30, turn: 1 };
      const delta = { trustAI: -10 };

      const newState = applyDelta(state, delta);

      expect(newState.trustAI).toBe(0); // -5 ではなく 0
    });

    it('should not mutate original state', () => {
      const state = { trustAI: 50, trustBoss: 50, risk: 30, turn: 1 };
      const delta = { trustAI: 10 };

      applyDelta(state, delta);

      expect(state.trustAI).toBe(50); // 元の値のまま
    });
  });
});
```

### 計算ロジックのテスト（Evaluator）

```typescript
import { describe, it, expect } from 'vitest';
import { Evaluator } from '../Evaluator';

describe('Evaluator', () => {
  const rules = [
    { score: 'alignment', formula: 'trustAI' },
    { score: 'loyalty', formula: 'trustBoss' },
    { score: 'safety', formula: 'invert:risk' },
  ];

  it('should calculate alignment from trustAI', () => {
    const evaluator = new Evaluator(rules);
    const state = { trustAI: 80, trustBoss: 60, risk: 30, turn: 10 };

    const score = evaluator.evaluate(state);

    expect(score.alignment).toBe(80);
  });

  it('should calculate safety as inverted risk', () => {
    const evaluator = new Evaluator(rules);
    const state = { trustAI: 50, trustBoss: 50, risk: 30, turn: 10 };

    const score = evaluator.evaluate(state);

    expect(score.safety).toBe(70); // 100 - 30
  });
});
```

### 条件判定のテスト（EndingRouter）

```typescript
import { describe, it, expect } from 'vitest';
import { EndingRouter } from '../EndingRouter';

describe('EndingRouter', () => {
  const endings = [
    {
      id: 'harmony',
      title: '調和の果てに',
      description: '...',
      conditions: [
        { field: 'alignment', operator: '>=', value: 70 },
        { field: 'loyalty', operator: '>=', value: 60 },
      ],
      priority: 100,
    },
    {
      id: 'default',
      title: '曖昧な結末',
      description: '...',
      conditions: [],
      priority: 0,
    },
  ];

  it('should return matching ending', () => {
    const router = new EndingRouter(endings);
    const score = { alignment: 80, loyalty: 70, safety: 60 };

    const ending = router.route(score);

    expect(ending?.id).toBe('harmony');
  });

  it('should return default when no conditions match', () => {
    const router = new EndingRouter(endings);
    const score = { alignment: 30, loyalty: 30, safety: 30 };

    const ending = router.route(score);

    expect(ending?.id).toBe('default');
  });

  it('should evaluate endings by priority (high to low)', () => {
    const router = new EndingRouter(endings);
    // 優先度の高いエンディングが先に評価される
    // ...
  });
});
```

### 統合テスト（GameController）

```typescript
import { describe, it, expect, beforeEach } from 'vitest';
import { GameController } from '../GameController';
import { Evaluator } from '../Evaluator';
import { EndingRouter } from '../EndingRouter';

describe('GameController', () => {
  let controller: GameController;

  beforeEach(() => {
    const evaluator = new Evaluator(rules);
    const endingRouter = new EndingRouter(endings);
    controller = new GameController(
      initialState,
      [],
      evaluator,
      endingRouter,
      gameConfig
    );
  });

  describe('applyChoiceDelta', () => {
    it('should update state with delta', () => {
      controller.applyChoiceDelta({ trustAI: 10 });

      const state = controller.getState();

      expect(state.trustAI).toBe(60); // 50 + 10
    });

    it('should increment turn', () => {
      controller.applyChoiceDelta({ trustAI: 10 });

      const state = controller.getState();

      expect(state.turn).toBe(2);
    });

    it('should not apply delta after game end', () => {
      // ゲーム終了状態にする
      for (let i = 0; i < 30; i++) {
        controller.applyChoiceDelta({ trustAI: 1 });
      }

      const stateBefore = controller.getState();
      controller.applyChoiceDelta({ trustAI: 10 });
      const stateAfter = controller.getState();

      expect(stateAfter.trustAI).toBe(stateBefore.trustAI);
    });
  });

  describe('getCurrentPhase', () => {
    it('should return early for turns 1-10', () => {
      expect(controller.getCurrentPhase()).toBe('early');
    });

    it('should return middle for turns 11-20', () => {
      for (let i = 0; i < 10; i++) {
        controller.applyChoiceDelta({});
      }

      expect(controller.getCurrentPhase()).toBe('middle');
    });
  });
});
```

## テストデータの準備

### フィクスチャの使用

```typescript
// __tests__/fixtures/gameData.ts
export const initialState = {
  trustAI: 50,
  trustBoss: 50,
  risk: 30,
  turn: 1,
};

export const rules = [
  { score: 'alignment', formula: 'trustAI' },
  { score: 'loyalty', formula: 'trustBoss' },
  { score: 'safety', formula: 'invert:risk' },
];

export const endings = [
  // ...
];

// テストファイルで使用
import { initialState, rules, endings } from './fixtures/gameData';
```

## エッジケースのテスト

必ずテストすべきエッジケース:

1. **境界値**: 0, 100, maxTurn
2. **空の入力**: 空配列、undefined、null
3. **不正な入力**: 範囲外の値、存在しないID
4. **状態遷移**: ゲーム開始直後、ゲーム終了直後
