# コンポーネント層テストパターン

コンポーネント層（`src/components/`）のテスト作成ガイドです。

## 対象

- チャットコンポーネント（ChatList, ChatRoom, ChoiceButtons）
- 履歴コンポーネント（EndingList, EndingCard, EndingDetailModal）
- 共通コンポーネント

## 特徴

- React Testing Library を使用
- ユーザー視点でのテスト
- DOM の状態とインタラクションをテスト

## セットアップ

### 必要なパッケージ

```bash
npm install -D @testing-library/react @testing-library/jest-dom @testing-library/user-event
```

### テストセットアップファイル

```typescript
// vitest.setup.ts
import '@testing-library/jest-dom';
```

```typescript
// vitest.config.ts
export default defineConfig({
  test: {
    environment: 'jsdom',
    setupFiles: ['./vitest.setup.ts'],
  },
});
```

## 基本パターン

### 表示のテスト

```typescript
import { describe, it, expect } from 'vitest';
import { render, screen } from '@testing-library/react';
import { EndingCard } from '../EndingCard';

describe('EndingCard', () => {
  const mockEnding = {
    id: 'harmony',
    title: '調和の果てに',
    description: 'テスト説明文',
    conditions: [],
    priority: 100,
  };

  describe('when unlocked', () => {
    it('should display ending title', () => {
      render(
        <EndingCard
          ending={mockEnding}
          isUnlocked={true}
          onClick={() => {}}
        />
      );

      expect(screen.getByText('調和の果てに')).toBeInTheDocument();
    });

    it('should show check icon', () => {
      render(
        <EndingCard
          ending={mockEnding}
          isUnlocked={true}
          onClick={() => {}}
        />
      );

      // SVG アイコンの存在確認
      const button = screen.getByRole('button');
      expect(button.querySelector('svg')).toBeInTheDocument();
    });

    it('should be clickable', () => {
      render(
        <EndingCard
          ending={mockEnding}
          isUnlocked={true}
          onClick={() => {}}
        />
      );

      const button = screen.getByRole('button');
      expect(button).toBeEnabled();
    });
  });

  describe('when locked', () => {
    it('should display "???" instead of title', () => {
      render(
        <EndingCard
          ending={mockEnding}
          isUnlocked={false}
          onClick={() => {}}
        />
      );

      expect(screen.getByText('???')).toBeInTheDocument();
      expect(screen.queryByText('調和の果てに')).not.toBeInTheDocument();
    });

    it('should not be clickable', () => {
      render(
        <EndingCard
          ending={mockEnding}
          isUnlocked={false}
          onClick={() => {}}
        />
      );

      // ボタンではなく div として表示
      expect(screen.queryByRole('button')).not.toBeInTheDocument();
    });
  });
});
```

### インタラクションのテスト

```typescript
import { describe, it, expect, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { ChoiceButtons } from '../ChoiceButtons';

describe('ChoiceButtons', () => {
  const mockChoices = [
    { id: 'choice_a', text: '選択肢A' },
    { id: 'choice_b', text: '選択肢B' },
  ];

  it('should render all choices', () => {
    render(<ChoiceButtons choices={mockChoices} onSelect={() => {}} />);

    expect(screen.getByText('選択肢A')).toBeInTheDocument();
    expect(screen.getByText('選択肢B')).toBeInTheDocument();
  });

  it('should call onSelect with choice when clicked', async () => {
    const user = userEvent.setup();
    const handleSelect = vi.fn();

    render(<ChoiceButtons choices={mockChoices} onSelect={handleSelect} />);

    await user.click(screen.getByText('選択肢A'));

    expect(handleSelect).toHaveBeenCalledWith(mockChoices[0]);
  });

  it('should render nothing when choices is empty', () => {
    const { container } = render(
      <ChoiceButtons choices={[]} onSelect={() => {}} />
    );

    expect(container.firstChild).toBeNull();
  });
});
```

### モーダルのテスト

```typescript
import { describe, it, expect, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { EndingDetailModal } from '../EndingDetailModal';

describe('EndingDetailModal', () => {
  const mockEnding = {
    id: 'harmony',
    title: '調和の果てに',
    description: 'あなたの選択により...',
    conditions: [],
    priority: 100,
  };

  it('should display ending details', () => {
    render(<EndingDetailModal ending={mockEnding} onClose={() => {}} />);

    expect(screen.getByText('調和の果てに')).toBeInTheDocument();
    expect(screen.getByText('あなたの選択により...')).toBeInTheDocument();
  });

  it('should call onClose when close button clicked', async () => {
    const user = userEvent.setup();
    const handleClose = vi.fn();

    render(<EndingDetailModal ending={mockEnding} onClose={handleClose} />);

    await user.click(screen.getByText('閉じる'));

    expect(handleClose).toHaveBeenCalled();
  });

  it('should call onClose when overlay clicked', async () => {
    const user = userEvent.setup();
    const handleClose = vi.fn();

    render(<EndingDetailModal ending={mockEnding} onClose={handleClose} />);

    // オーバーレイ（背景）をクリック
    const overlay = screen.getByRole('dialog').parentElement;
    await user.click(overlay!);

    expect(handleClose).toHaveBeenCalled();
  });

  it('should call onClose when Escape key pressed', async () => {
    const user = userEvent.setup();
    const handleClose = vi.fn();

    render(<EndingDetailModal ending={mockEnding} onClose={handleClose} />);

    await user.keyboard('{Escape}');

    expect(handleClose).toHaveBeenCalled();
  });
});
```

### ストア連携コンポーネントのテスト

```typescript
import { describe, it, expect, beforeEach } from 'vitest';
import { render, screen } from '@testing-library/react';
import { EndingList } from '../EndingList';
import { useGameStore } from '@/stores';

// ストアをモック
vi.mock('@/stores', () => ({
  useGameStore: vi.fn(),
}));

describe('EndingList', () => {
  beforeEach(() => {
    vi.mocked(useGameStore).mockReturnValue({
      unlockedEndings: ['harmony'],
    });
  });

  it('should display progress', () => {
    render(<EndingList />);

    expect(screen.getByText('1/7')).toBeInTheDocument();
  });

  it('should show unlocked endings with title', () => {
    render(<EndingList />);

    expect(screen.getByText('調和の果てに')).toBeInTheDocument();
  });

  it('should show locked endings as ???', () => {
    render(<EndingList />);

    // 6つの "???" が表示される（7 - 1 unlocked）
    const lockedItems = screen.getAllByText('???');
    expect(lockedItems).toHaveLength(6);
  });
});
```

## テストのベストプラクティス

### 1. ユーザー視点でテスト

```typescript
// ❌ 実装詳細のテスト
expect(component.state.isOpen).toBe(true);

// ✅ ユーザー視点のテスト
expect(screen.getByRole('dialog')).toBeVisible();
```

### 2. アクセシビリティ重視のクエリ

```typescript
// 優先順位（高い順）
screen.getByRole('button', { name: '送信' });  // 最優先
screen.getByLabelText('メールアドレス');
screen.getByPlaceholderText('検索...');
screen.getByText('ログイン');
screen.getByTestId('submit-button');  // 最終手段
```

### 3. 非同期処理の待機

```typescript
import { waitFor } from '@testing-library/react';

it('should show loading then content', async () => {
  render(<AsyncComponent />);

  // ローディング表示を確認
  expect(screen.getByText('読み込み中...')).toBeInTheDocument();

  // コンテンツ表示を待機
  await waitFor(() => {
    expect(screen.getByText('コンテンツ')).toBeInTheDocument();
  });
});
```

### 4. スナップショットテストは控えめに

```typescript
// ❌ コンポーネント全体のスナップショット（脆い）
expect(container).toMatchSnapshot();

// ✅ 重要な部分だけスナップショット
expect(screen.getByRole('heading')).toMatchSnapshot();
```

## Next.js 固有の考慮事項

### Link コンポーネント

```typescript
import { vi } from 'vitest';

// next/navigation をモック
vi.mock('next/navigation', () => ({
  useRouter: () => ({
    push: vi.fn(),
    back: vi.fn(),
  }),
}));
```

### 'use client' コンポーネント

クライアントコンポーネントは通常通りテスト可能。サーバーコンポーネントは別途考慮が必要。
