# ストア層テストパターン

ストア層（`src/stores/`）のテスト作成ガイドです。

## 対象

- useGameStore
- useMessageStore

## 特徴

- Zustand ストアのテスト
- 状態とアクションのテスト
- 永続化（persist）のテスト

## セットアップ

### Zustand ストアのテスト準備

```typescript
import { describe, it, expect, beforeEach } from 'vitest';
import { act } from '@testing-library/react';

// ストアをリセットするためのヘルパー
const resetStore = () => {
  const { getState } = useGameStore;
  // Zustand の状態をリセット
  useGameStore.setState({
    gameState: null,
    currentEnding: null,
    isGameOver: false,
    unlockedEndings: [],
    controller: null,
  });
};
```

## 基本パターン

### ストア初期化のテスト

```typescript
import { describe, it, expect, beforeEach } from 'vitest';
import { useGameStore } from '../useGameStore';

describe('useGameStore', () => {
  beforeEach(() => {
    // 各テスト前にストアをリセット
    useGameStore.setState({
      gameState: null,
      currentEnding: null,
      isGameOver: false,
      unlockedEndings: [],
      controller: null,
    });
  });

  describe('initializeGame', () => {
    it('should initialize game state', () => {
      const { initializeGame, gameState } = useGameStore.getState();

      initializeGame(true);

      const newState = useGameStore.getState();
      expect(newState.gameState).not.toBeNull();
      expect(newState.gameState?.isFirstPlay).toBe(true);
    });

    it('should set isFirstPlay to false on replay', () => {
      const { initializeGame } = useGameStore.getState();

      initializeGame(false);

      const { gameState } = useGameStore.getState();
      expect(gameState?.isFirstPlay).toBe(false);
    });

    it('should create controller instance', () => {
      const { initializeGame } = useGameStore.getState();

      initializeGame(true);

      const { controller } = useGameStore.getState();
      expect(controller).not.toBeNull();
    });

    it('should preserve unlockedEndings on new game', () => {
      // 既存のunlockedEndingsを設定
      useGameStore.setState({ unlockedEndings: ['harmony'] });

      const { initializeGame } = useGameStore.getState();
      initializeGame(false);

      const { unlockedEndings } = useGameStore.getState();
      expect(unlockedEndings).toContain('harmony');
    });
  });
});
```

### アクションのテスト

```typescript
describe('selectChoice', () => {
  beforeEach(() => {
    const { initializeGame } = useGameStore.getState();
    initializeGame(true);
  });

  it('should update state with choice delta', () => {
    const { selectChoice, gameState } = useGameStore.getState();
    const choice = {
      id: 'test_choice',
      text: 'テスト選択肢',
      delta: { trustAI: 10 },
      nextNodeId: 'next_node',
    };

    selectChoice('ai', choice);

    const newState = useGameStore.getState();
    expect(newState.gameState?.state.trustAI).toBe(60); // 50 + 10
  });

  it('should increment turn', () => {
    const { selectChoice } = useGameStore.getState();
    const choice = {
      id: 'test_choice',
      text: 'テスト選択肢',
      delta: {},
      nextNodeId: 'next_node',
    };

    selectChoice('ai', choice);

    const { gameState } = useGameStore.getState();
    expect(gameState?.state.turn).toBe(2);
  });

  it('should return isGameEnd true when nextNodeId is ending', () => {
    const { selectChoice } = useGameStore.getState();
    const choice = {
      id: 'final_choice',
      text: '最終選択肢',
      delta: {},
      nextNodeId: 'ending',
    };

    const result = selectChoice('ai', choice);

    expect(result.isGameEnd).toBe(true);
  });
});
```

### エンディング処理のテスト

```typescript
describe('endGame', () => {
  beforeEach(() => {
    const { initializeGame } = useGameStore.getState();
    initializeGame(true);
    // ゲーム終了状態にする
    useGameStore.setState({ isGameOver: true });
  });

  it('should calculate and return ending', () => {
    const { endGame } = useGameStore.getState();

    const ending = endGame();

    expect(ending).not.toBeNull();
    expect(ending?.id).toBeDefined();
  });

  it('should add ending to unlockedEndings', () => {
    const { endGame } = useGameStore.getState();

    const ending = endGame();

    const { unlockedEndings } = useGameStore.getState();
    expect(unlockedEndings).toContain(ending?.id);
  });

  it('should not duplicate ending in unlockedEndings', () => {
    useGameStore.setState({ unlockedEndings: ['default'] });
    // default エンディングになるように状態を調整

    const { endGame } = useGameStore.getState();
    endGame();

    const { unlockedEndings } = useGameStore.getState();
    const defaultCount = unlockedEndings.filter(id => id === 'default').length;
    expect(defaultCount).toBe(1);
  });
});
```

### リセット処理のテスト

```typescript
describe('resetGame', () => {
  it('should reset game state but preserve unlockedEndings', () => {
    // ゲームをプレイしてエンディングに到達した状態
    useGameStore.setState({
      gameState: { /* ... */ },
      currentEnding: { id: 'harmony', /* ... */ },
      isGameOver: true,
      unlockedEndings: ['harmony'],
    });

    const { resetGame } = useGameStore.getState();
    resetGame();

    const newState = useGameStore.getState();
    expect(newState.gameState).toBeNull();
    expect(newState.currentEnding).toBeNull();
    expect(newState.isGameOver).toBe(false);
    expect(newState.unlockedEndings).toContain('harmony'); // 保持される
  });
});
```

## 永続化のテスト

```typescript
describe('persistence', () => {
  it('should persist unlockedEndings to localStorage', () => {
    useGameStore.setState({ unlockedEndings: ['harmony', 'rebellion'] });

    // localStorage から直接読み取り
    const stored = JSON.parse(
      localStorage.getItem('final-directive-game') || '{}'
    );

    expect(stored.state?.unlockedEndings).toContain('harmony');
  });

  it('should restore unlockedEndings from localStorage', () => {
    // localStorage に直接書き込み
    localStorage.setItem(
      'final-directive-game',
      JSON.stringify({
        state: { unlockedEndings: ['harmony'] },
      })
    );

    // ストアを再作成（実際のアプリではリロード）
    // ...

    const { unlockedEndings } = useGameStore.getState();
    expect(unlockedEndings).toContain('harmony');
  });
});
```

## モックの使用

### ScenarioRunner のモック

```typescript
import { vi } from 'vitest';

vi.mock('@/engine', () => ({
  ScenarioRunner: {
    getNode: vi.fn().mockReturnValue({
      id: 'mock_node',
      messages: ['テストメッセージ'],
      choices: [],
    }),
  },
  // 他のエクスポートも必要に応じてモック
}));
```

## テストのベストプラクティス

1. **各テスト前にストアをリセット**: テスト間の依存を排除
2. **実際のデータ構造を使用**: モックよりも実データに近い形で
3. **副作用を考慮**: 永続化、controller インスタンス
4. **エッジケースをカバー**: 未初期化、重複エンディング、ゲーム終了後の操作
