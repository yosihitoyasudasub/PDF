# Testing スキル

テストの作成と品質管理を支援するスキルです。

## スキルの目的

- テスト作成のガイドラインを提供
- レイヤー別のテストパターンを定義
- テストカバレッジの維持を支援

## テスト方針

### テストピラミッド

```
        /\
       /  \      E2E テスト（少数・重要フローのみ）
      /----\
     /      \    統合テスト（ストア・API連携）
    /--------\
   /          \  ユニットテスト（多数・高速）
  --------------
```

### レイヤー別テスト戦略

| レイヤー | テスト種別 | 優先度 | ツール |
|----------|-----------|--------|--------|
| エンジン層 | ユニットテスト | 必須 | Vitest |
| ストア層 | ユニットテスト | 必須 | Vitest |
| コンポーネント | コンポーネントテスト | 推奨 | React Testing Library |
| ページ | 統合テスト | 推奨 | React Testing Library |
| E2E | E2Eテスト | オプション | Playwright |

### 何をテストすべきか

**必須（ビジネスロジック）**:
- 状態の変更ロジック（StateManager, applyDelta）
- 計算ロジック（Score計算、条件判定）
- 分岐ロジック（エンディング判定、フェーズ遷移）

**推奨（データフロー）**:
- ストアのアクション（initializeGame, selectChoice, endGame）
- データの永続化（LocalStorage保存/復元）

**オプション（UI）**:
- ユーザーインタラクション（ボタンクリック、画面遷移）
- 表示条件（到達済み/未到達の表示切替）

### 何をテストしないか

- 外部ライブラリの動作（React, Zustand, Next.js）
- スタイリング（Tailwind CSSクラス）
- 静的なマークアップ

## テスト作成ガイドライン

### ファイル配置

```
src/
├── engine/
│   ├── StateManager.ts
│   └── __tests__/
│       └── StateManager.test.ts    # 同階層の__tests__に配置
├── stores/
│   ├── useGameStore.ts
│   └── __tests__/
│       └── useGameStore.test.ts
└── components/
    ├── history/
    │   ├── EndingList.tsx
    │   └── __tests__/
    │       └── EndingList.test.tsx
```

### 命名規則

- テストファイル: `[対象ファイル名].test.ts(x)`
- describeブロック: 対象のクラス名/関数名
- itブロック: 「〜すべき」形式で期待動作を記述

```typescript
describe('StateManager', () => {
  describe('applyDelta', () => {
    it('should increment turn by 1', () => {
      // ...
    });

    it('should clamp values between 0 and 100', () => {
      // ...
    });
  });
});
```

### テストの構造（AAA パターン）

```typescript
it('should calculate score correctly', () => {
  // Arrange（準備）
  const state = { trustAI: 80, trustBoss: 60, risk: 30, turn: 10 };
  const evaluator = new Evaluator(rules);

  // Act（実行）
  const score = evaluator.evaluate(state);

  // Assert（検証）
  expect(score.alignment).toBe(80);
  expect(score.loyalty).toBe(60);
  expect(score.safety).toBe(70);
});
```

## パターン別ガイド

詳細は以下のパターンファイルを参照:

- `patterns/engine.md` - エンジン層テストパターン
- `patterns/store.md` - ストア層テストパターン
- `patterns/component.md` - コンポーネントテストパターン

## テスト実行

```bash
# 全テスト実行
npm test

# ウォッチモード
npm run test:watch

# カバレッジ付き
npm run test:coverage

# 特定ファイルのみ
npm test -- StateManager
```

## CI/CD連携

プルリクエスト時に自動実行すべきチェック:

1. `npm run typecheck` - 型チェック
2. `npm test` - ユニットテスト
3. `npm run build` - ビルド確認

## テスト追加のタイミング

### 必須タイミング

1. **新機能実装時**: 実装と同時にテストを作成
2. **バグ修正時**: 再発防止のためのテストを追加
3. **リファクタリング時**: 既存テストで動作保証

### 推奨タイミング

1. **コードレビュー前**: テストがないコードはレビュー対象外
2. **重要ロジック変更時**: 影響範囲のテストを確認・追加
