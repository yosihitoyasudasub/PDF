---
name: proposal
description: アイデアを実装せずに検討・設計するためのスキル。`.proposals/`フォルダにrequirements.mdとdesign.mdを作成する。実装・テストは行わない。
allowed-tools: Read, Write, Edit
---

# Proposal スキル

アイデアを検討・設計するためのスキルです。**実装はしません。**

## スキルの目的

- `.proposals/[YYYYMMDD]-[アイデア名]/` に仕様書・設計書を作成する
- 実装に踏み切る前にアイデアの実現可能性・設計を深く考える
- 後で `.steering/` に昇格させるか、破棄するかを判断するための材料を作る

## 重要な制約

**🚫 このスキルでは以下を行ってはならない:**
- コードの実装
- テストの実装
- tasklist.md の作成
- ソースコードファイルの編集

**✅ このスキルで行うこと:**
- requirements.md（要件定義）の作成
- design.md（設計書）の作成
- ユーザーとの対話による要件の深掘り

## 手順

### ステップ1: プロポーザルディレクトリの作成

```
現在の日付を取得し、`.proposals/[YYYYMMDD]-[アイデア名]/` の形式でディレクトリ名を決定
```

アイデア名は英小文字・ハイフン区切りで短く（例: `player-attack`, `day-night-music`）。

### ステップ2: 既存コンテキストの確認

以下を読んでアイデアに関係する既存設計を把握する:
- `docs/product-requirements.md`
- `docs/functional-design.md`
- `docs/architecture.md`
- 関連する `.proposals/` や `.steering/` フォルダ

### ステップ3: requirements.md の作成

テンプレート: `.claude/skills/proposal/templates/requirements.md`

**1ファイルずつ作成し、ユーザーの承認を得てから次に進む。**

プレースホルダーをアイデアの具体的な内容に置き換える。
実装確約ではなく「もし実装するとしたらどうか」という検討視点で書く。

### ステップ4: design.md の作成

テンプレート: `.claude/skills/proposal/templates/design.md`

**requirements.md をユーザーが承認した後に作成する。**

設計上の選択肢・トレードオフを明示する。
「実装方法」ではなく「どう設計するか」の検討に集中する。

### ステップ5: ユーザーへの報告

作成完了後、以下を伝える:

```
プロポーザルを作成しました:
- .proposals/[日付]-[アイデア名]/requirements.md
- .proposals/[日付]-[アイデア名]/design.md

次のステップ:
- 実装する場合 → `steering` スキルで `.steering/` フォルダを作成
- 破棄する場合 → `.proposals/` フォルダを削除
- 保留する場合 → そのまま残す
```

## `.proposals/` → `.steering/` 昇格時の注意

プロポーザルを実装に昇格させる場合:
1. `.proposals/` の requirements.md と design.md を参照元として使う
2. `steering` スキルで新しい `.steering/[YYYYMMDD]-[タスク名]/` を作成する
3. プロポーザルの内容を踏まえて steering ファイルを作成する（コピーではなく改めて作成）
4. `.proposals/` フォルダ自体は残す（記録として）
