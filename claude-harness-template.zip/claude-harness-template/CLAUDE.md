# {プロジェクト名}

## 技術スタック
<!-- 新プロジェクト開始時に必ず記入する。evaluator・workflows はこの節を参照する -->
- **ビルド**: {例: Vite 6.x}
- **UI**: {例: React 19 + TypeScript 5.x}
- **状態管理**: {例: Zustand 5.x}
- **デプロイ**: {例: Vercel（静的配信）}
- パッケージマネージャー: {例: npm}

## ビルド・検証コマンド
<!-- evaluator の自動検証・Stop フック・workflows はこの節が単一情報源 -->
- 開発サーバー: `npm run dev`
- プロダクションビルド: `npm run build`
- 型チェック: `npx tsc --noEmit`
- テスト: `npm test`（単一テストを優先: `npm test -- tests/unit/[テストファイル]`）
- リント: `npm run lint`

## プロジェクト固有の重点リソース
<!-- evaluator の負債ゲート「リソース解放漏れ」で重点的に見るリソースがあれば記入（例: Three.js の geometry/material/texture の dispose）。なければ「なし」 -->
- {なし / 例: WebGL リソースの dispose 経路}

## スペック駆動開発ルール

### IMPORTANT: ドキュメント作成時のルール
1ファイルずつ作成し、**必ずユーザーの承認を得てから次に進む**。

例外: `/setup-project` の永続ドキュメント一括作成では、PRD（`docs/product-requirements.md`）の承認後、残りのドキュメントはPRDを元に自動作成してよい。

### IMPORTANT: 実装前の確認
新しい実装を始める前に、必ず以下を確認:
1. CLAUDE.mdを読む
2. 関連する永続ドキュメント(`docs/`)を読む
3. Grepで既存の類似実装を検索
4. 既存パターンを理解してから実装開始

### ステアリングファイル管理
作業計画・実装・検証時は`steering`スキルを使用する。

### プロポーザルファイル管理
アイデアを検討・設計するだけで実装しない場合は`proposal`スキルを使用する。

### 技術的負債の管理
- 負債台帳: `docs/tech-debt.md` — 各タスクの振り返り時に、導入・発見した負債を1行ずつ記録する
- **返済トリガー**: 台帳に重要度「高」が3件以上、または未返済が合計10件以上溜まったら、次の機能追加より先にリファクタリングタスクの作成をユーザーに提案する
- Evaluatorのコード健全性チェック（ファイル300行超・重複3例目・リソース解放漏れ・`as unknown`新規追加）は全スプリント共通の合格条件

### ドキュメント構造
- 永続ドキュメント: `docs/` — プロジェクト全体の設計（北極星）
- 下書き・アイデア: `docs/ideas/` — 永続ドキュメントの草案
- アイデア検討: `.proposals/[YYYYMMDD]-[アイデア名]/`（requirements.md, design.md）— **実装なし、設計検討のみ**
- 作業単位: `.steering/[YYYYMMDD]-[タスク名]/`（requirements.md, design.md, tasklist.md）

### `.proposals/` vs `.steering/` の使い分け

| | `.proposals/` | `.steering/` |
|---|---|---|
| 目的 | アイデアの検討・設計 | 実装タスクの管理 |
| 実装 | **しない** | する |
| テスト | **しない** | する |
| 作成ファイル | requirements.md, design.md | requirements.md, design.md, tasklist.md, issues.md, handoff.md, feedback.md |
| 使用スキル | `proposal` | `steering` |
